package tools;

import java.io.IOException;
import java.util.Scanner;

import option.GameOptions;

/**
 * 
 * Cette classe sert � saisir et contr�ler les saisis claviers de l'utilisateur gr�ce � la m�thode Scanner.
 * @author Zyk
 *
 */

public class Input {

	/**
	 * M�thode qui permet de contr�ler la saisie de l'utilisateur et de la m�moriser pour une utilisation ult�rieure.
	 * 
	 * @return
	 * Tableau d'Integer
	 */
	/*	public Integer[] generateInput() {

		String userc = "";

		do {

			System.out.println("\r\nVeuillez entrer " + +pawns + " chiffres");
			userc = sc.nextLine();

			if (userc.length() != pawns) 
			{
				System.out.println("Attention, vous n'avez pas s�lectionn� le bon nombre de chiffre !");
			}  
			else 
			{	
				for ( int i=0; i<userc.length(); i++)
				{
					Input[i]=Integer.parseInt(""+userc.charAt(i));
				}
			}
		} while (userc.length() != pawns);

		return Input;
	}
	 */

}