package tools;

public interface IObserver {
	
	public void update();

}
