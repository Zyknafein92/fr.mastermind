package start;

public class Main {

	public static void main(String[] args) {

		Board newGame = new Board();
		newGame.Menu();

	}
}