package option;

public class GameOptions   {

	public static final int MAX_TRY = 15;
	public static final int PAWNS = 4;
	public static final int MAX_NUMBERS = 6;
	
}
 
 
